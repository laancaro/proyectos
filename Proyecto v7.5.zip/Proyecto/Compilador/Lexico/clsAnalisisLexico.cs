﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsAnalisisLexico.cs
 * Descripcion: Clase con los componentes necesarios para iniciar el Análisis Léxico.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.Data;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Compilador.AdministracionSimbolos;
using Compilador.Errores;

namespace Compilador.Lexico
{
    /// <summary>
    /// Clase con los componentes necesarios para iniciar el Análisis Léxico.
    /// </summary>
    public class clsAnalisisLexico
    {
        #region Declaraciones

        private const string lexico = "Léxico";

        #endregion

        #region Constructores
        /// <summary>
        /// Constructor.
        /// </summary>
        public clsAnalisisLexico() { }

        #endregion

        #region Métodos

        /// <summary>
        /// Método que analiza el fuente original y retorna la tabla de simbolos.
        /// </summary>
        /// <param name="codigoInicial">Arreglo char con el fuente original.</param>
        /// <param name="listaSimbolos">Lista de palabras reservadas, simbolos y operadores propios del lenguaje.</param>
        /// <returns>DataTable con la Tabla de Simbolos</returns>
        public DataTable GenerarTablaTokens(char[] codigoInicial, List<clsSimbolos> listaSimbolos)
        {
            int cantidadComillas = 0;
            char[] codigo;
            int posicionCaracter, posicionEnCodigo;
            string concatena;
            int contadorIDToken = 50;
            DataTable dt = new DataTable();
            dt.Columns.Add("Codigo");
            dt.Columns.Add("Simbolo");
            dt.Columns.Add("Token");
            dt.Columns.Add("Posicion");
            //dt.Columns.Add("Ambito");
            DataRow dr;
            try
            {
                codigo = codigoInicial;
                posicionCaracter = 0;
                posicionEnCodigo = 0;
                concatena = string.Empty;
                // Mientras posicionCodigo sea menor a la longitud de la cadena.
                while (posicionCaracter < codigo.Length)
                {
                    // Discrimino ante cualquier salto de linea, espacio y tabulador.
                    if (codigo[posicionCaracter].Equals(' ') || codigo[posicionCaracter].Equals(" ") || codigo[posicionCaracter].Equals('\n') || codigo[posicionCaracter].Equals('\t') || codigo[posicionCaracter].Equals('\r'))
                    {
                        posicionCaracter += 1; // Si: Avanzo al siguiente caracter.
                    }

                    /*
                     * INICIO DE BUSQUEDA DE CADENAS
                     */
                    if (codigo[posicionCaracter].Equals('"')) // Si inicio con simbolo '"'...
                    {
                        posicionEnCodigo = posicionCaracter;
                        // Concateno el caracter.
                        concatena = concatena + codigo[posicionCaracter];
                        posicionCaracter += 1; // Avanzamos al siguiente caracter.
                        cantidadComillas++;
                        // Verifico que no sea el último caracter.
                        if (posicionCaracter < codigo.Length - 1)
                        {
                            // Mientras sea Número, Letra ó '_'.
                            while (char.IsLetterOrDigit(codigo[posicionCaracter]) || codigo[posicionCaracter].Equals('_') || codigo[posicionCaracter].Equals('$') || codigo[posicionCaracter].Equals('"') || codigo[posicionCaracter].Equals(' '))
                            {
                                if (codigo[posicionCaracter].Equals('"'))
                                {
                                    cantidadComillas++;
                                }
                                // Concateno y recorro el siguiente caracter
                                concatena = concatena + codigo[posicionCaracter];
                                posicionCaracter += 1;

                                // Verifico si estoy en el último caracter.
                                if (posicionCaracter.Equals(codigo.Length))
                                {
                                    break; // Si es así salgo del bucle.
                                }
                                if (cantidadComillas > 1)
                                {
                                    cantidadComillas = 0;
                                    break;
                                }
                            }
                        }
                        // Genero un nuevo Identificador.
                        dr = dt.NewRow();
                        dr["Codigo"] = contadorIDToken;
                        dr["Simbolo"] = concatena;
                        dr["Token"] = "Cadena";
                        dr["Posicion"] = posicionEnCodigo;
                        dt.Rows.Add(dr);
                        // Aumento contadorIDToken en 1 como ID único para próximo token a encontrar en el código.
                        contadorIDToken++;
                        // Reinicio de la Concatenación.
                        concatena = string.Empty;
                    }



                    /*
                     * INICIO DE BUSQUEDA DE IDENTIFICADORES
                     */
                    if (codigo[posicionCaracter].Equals('$')) // Si inicio con simbolo '$'...
                    {
                        posicionEnCodigo = posicionCaracter;
                        // Concateno el caracter.
                        concatena = concatena + codigo[posicionCaracter];
                        posicionCaracter += 1; // Avanzamos al siguiente caracter.

                        // Verifico que no sea el último caracter.
                        if (posicionCaracter < codigo.Length - 1)
                        {
                            // Mientras sea Número, Letra ó '_'.
                            while (char.IsLetterOrDigit(codigo[posicionCaracter]) || codigo[posicionCaracter].Equals('_') || codigo[posicionCaracter].Equals('$'))
                            {
                                // Concateno y recorro el siguiente caracter
                                concatena = concatena + codigo[posicionCaracter];
                                posicionCaracter += 1;

                                // Verifico si estoy en el último caracter.
                                if (posicionCaracter.Equals(codigo.Length))
                                {
                                    break; // Si es así salgo del bucle.
                                }
                            }
                        }
                        // Genero un nuevo Identificador.
                        dr = dt.NewRow();
                        dr["Codigo"] = contadorIDToken;
                        dr["Simbolo"] = concatena;
                        dr["Token"] = "Identificador";
                        dr["Posicion"] = posicionEnCodigo;
                        dt.Rows.Add(dr);
                        // Aumento contadorIDToken en 1 como ID único para próximo token a encontrar en el código.
                        contadorIDToken++;
                        // Reinicio de la Concatenación.
                        concatena = string.Empty;
                    }

                    /*
                     * INICIO DE BUSQUEDA DE PALABRAS RESERVADAS
                     */
                    if (char.IsLetter(codigo[posicionCaracter])) // Si es una letra...
                    {
                        posicionEnCodigo = posicionCaracter;
                        // Concateno el caracter.
                        concatena = concatena + codigo[posicionCaracter];
                        posicionCaracter += 1; // Avanzamos al siguiente caracter.

                        // Verifico que no sea el último caracter.
                        if (posicionCaracter < codigo.Length - 1)
                        {
                            // Mientras sea Número, Letra ó '_'.
                            while (char.IsLetterOrDigit(codigo[posicionCaracter]) || codigo[posicionCaracter].Equals('_'))
                            {
                                // Concateno y recorro el siguiente caracter
                                concatena = concatena + codigo[posicionCaracter];
                                posicionCaracter += 1;

                                // Verifico si estoy en el último caracter.
                                if (posicionCaracter.Equals(codigo.Length))
                                {
                                    break; // Si es así salgo del bucle.
                                }
                            }
                        }
                        // Determino si hay Palabras Reservadas o ID's.
                        int nrevisiones = 0;
                        foreach (clsSimbolos item in listaSimbolos)
                        {
                            if (item.Elemento.Equals(concatena))
                            {
                                dr = dt.NewRow();
                                dr["Codigo"] = item.ID;
                                dr["Simbolo"] = concatena;
                                dr["Token"] = item.Atributo;
                                dr["Posicion"] = posicionEnCodigo;
                                dt.Rows.Add(dr);
                                break;
                            }
                            else
                            {
                                nrevisiones++;
                            }
                        }
                        if (nrevisiones.Equals(listaSimbolos.Count))
                        {
                            dr = dt.NewRow();
                            dr["Codigo"] = contadorIDToken;
                            dr["Simbolo"] = concatena;
                            dr["Token"] = "Elemento Desconocido";
                            dr["Posicion"] = posicionEnCodigo;
                            dt.Rows.Add(dr);
                            nrevisiones = 0;
                            // Aumento contadorIDToken en 1 como ID único para próximo token a encontrar en el código.
                            contadorIDToken++;
                            // Se genera un nuevo error para que sea recuperado posteriormente por el modulo de errores.
                            clsFlujoErrores.NuevoError(lexico, "El elemento \'" + concatena + "\' no es reconocido como valido.", posicionEnCodigo.ToString());
                        }
                        // Reinicio de la Concatenación.
                        concatena = string.Empty;

                    }
                    else if (char.IsNumber(codigo[posicionCaracter])) // Si es un número...
                    {
                        /*
                        * INICIO DE BUSQUEDA DE NÚMEROS
                        */
                        posicionEnCodigo = posicionCaracter;
                        // Concateno el caracter.
                        concatena = concatena + codigo[posicionCaracter];
                        posicionCaracter += 1; // Avanzamos al siguiente caracter.

                        // Verifico que no sea el último caracter.
                        if (posicionCaracter < codigo.Length - 1)
                        {
                            // Mientras sea Número, Letra ó '_'.
                            while (char.IsNumber(codigo[posicionCaracter]))
                            {
                                // Concateno y recorro el siguiente caracter
                                concatena = concatena + codigo[posicionCaracter];
                                posicionCaracter += 1;

                                // Verifico si estoy en el último caracter.
                                if (posicionCaracter.Equals(codigo.Length))
                                {
                                    break; // Si es así salgo del bucle.
                                }
                            }
                        }
                        dr = dt.NewRow();
                        dr["Codigo"] = contadorIDToken;
                        dr["Simbolo"] = concatena;
                        dr["Token"] = "Número";
                        dr["Posicion"] = posicionEnCodigo;
                        dt.Rows.Add(dr);
                        // Reinicio de la Concatenación y aumento contadorIDToken en 1 como ID único para próximo token a encontrar en el código.
                        concatena = string.Empty;
                        contadorIDToken++;
                    }
                    else
                    {
                        /*
                        * INICIO DE BUSQUEDA DE OPERADORES Y DELIMITADORES
                        */
                        posicionEnCodigo = posicionCaracter;
                        // Concateno el caracter.
                        concatena = concatena + codigo[posicionCaracter];
                        posicionCaracter += 1; // Avanzamos al siguiente caracter.

                        // Determino si hay Palabras Reservadas o ID's.
                        if (concatena.Equals(">"))
                        {
                            dr = dt.NewRow();
                            dr["Codigo"] = 988;
                            dr["Simbolo"] = concatena;
                            dr["Token"] = "Operador";
                            dr["Posicion"] = posicionEnCodigo;
                            dt.Rows.Add(dr);
                        }
                        if (concatena.Equals("<"))
                        {
                            dr = dt.NewRow();
                            dr["Codigo"] = 989;
                            dr["Simbolo"] = concatena;
                            dr["Token"] = "Operador";
                            dr["Posicion"] = posicionEnCodigo;
                            dt.Rows.Add(dr);
                        }
                        int nrevisiones2 = 0;
                        foreach (clsSimbolos item in listaSimbolos)
                        {

                            if (item.Elemento.Equals(concatena))
                            {
                                dr = dt.NewRow();
                                dr["Codigo"] = item.ID;
                                dr["Simbolo"] = concatena;
                                dr["Token"] = item.Atributo;
                                dr["Posicion"] = posicionEnCodigo;
                                dt.Rows.Add(dr);
                                break;
                            }
                            else
                            {
                                nrevisiones2++;
                            }
                        }
                        // Reinicio de la Concatenación.
                        concatena = string.Empty;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return dt;
        }

        /// <summary>
        /// Analiza el código inicial en busca de errores léxicos.
        /// </summary>
        /// <param name="codigoOriginal">Codigo inicial</param>
        /// <returns>Retorna el código final</returns>
        public string AnalisisLexico(string codigoOriginal)
        {
            string codigoLimpio = string.Empty;
            int posicionInicioFin = 0;
            try
            {
                codigoLimpio = LimpiarComentarios(codigoOriginal);
                if (!this.TieneInicioFin(codigoLimpio))
                {
                    clsFlujoErrores.NuevoError(lexico, "No se encontro la definicion de inicio y/o fin", posicionInicioFin.ToString());
                }
            }
            catch (Exception)
            {
                throw;
            }
            return codigoLimpio;
        }

        /// <summary>
        /// Método que analiza las entradas de declaraciones y genera la tabla de simbolos final.
        /// </summary>
        /// <param name="codigoOriginal">Código original limpio</param>
        /// <returns></returns>
        public DataTable GenerarTablaSimbolos(string codigoOriginal)
        {
            int codigoUnico = 0;
            DataTable dt = new DataTable();
            dt.Columns.Add("Codigo");
            dt.Columns.Add("Identificador");
            dt.Columns.Add("Tipo");
            dt.Columns.Add("Valor");
            DataRow dr;
            #region Enteros
            Regex expresionENT = new Regex("\\bent \\$+([\\w\\d]{1,})\\s*\\=+\\s*(\".*\"?\\s*\"|\\d)+\\s*");
            MatchCollection coincidenciasENT = expresionENT.Matches(codigoOriginal);
            if (coincidenciasENT.Count > 0)
            {
                string declaracion = string.Empty;
                foreach (Match coincidenciaENT in coincidenciasENT)
                {
                    declaracion = coincidenciaENT.ToString();
                    Regex expresionIdentificador = new Regex(@"\$+([\w\d]{1,})+");
                    MatchCollection coincidenciasIdentificador = expresionIdentificador.Matches(declaracion);
                    dr = dt.NewRow();
                    if (coincidenciasIdentificador.Count > 0)
                    {
                        dr["Codigo"] = codigoUnico;
                        foreach (Match coincidenciaID in coincidenciasIdentificador)
                        {
                            dr["Identificador"] = coincidenciaID.ToString();
                        }
                        dr["Tipo"] = "Entero";
                    }
                    Regex expresionValor = new Regex(@"\s*\=+\s*(\d{1,})");
                    MatchCollection coincidenciasValor = expresionValor.Matches(declaracion);
                    string temporalENT = string.Empty;
                    if (coincidenciasValor.Count > 0)
                    {
                        foreach (Match coincidenciaValor in coincidenciasValor)
                        {
                            temporalENT = string.Empty;
                            temporalENT = coincidenciaValor.ToString();
                            temporalENT = temporalENT.Replace('=',' ');
                            temporalENT = temporalENT.Replace(';',' ');
                            dr["Valor"] = temporalENT.Trim();
                        }
                    }
                    else
                    {
                        dr["Valor"] = "Error";
                        //clsFlujoErrores.NuevoError("Semántico", "El tipo ent declarado para el identificador " + dr["Identificador"].ToString() + " no concuerda con su valor", "2");
                    }
                    dt.Rows.Add(dr);
                    codigoUnico++;
                }

            }
            #endregion

            #region Cadenas
            Regex expresionTXT = new Regex("\\btxt \\$+([\\w\\d]{1,})\\s*\\=?\\s*(\")?([\\w\\s\\d]{0,})(\")?\\s*");
            MatchCollection coincidenciasTXT = expresionTXT.Matches(codigoOriginal);
            if (coincidenciasTXT.Count > 0)
            {
                string declaracion = string.Empty;
                foreach (Match coincidenciaTXT in coincidenciasTXT)
                {
                    declaracion = coincidenciaTXT.ToString();
                    Regex expresionIdentificador = new Regex(@"\$+([\w\d]{1,})+");
                    MatchCollection coincidenciasIdentificador = expresionIdentificador.Matches(declaracion);
                    dr = dt.NewRow();
                    if (coincidenciasIdentificador.Count > 0)
                    {
                        dr["Codigo"] = codigoUnico;
                        foreach (Match coincidenciaID in coincidenciasIdentificador)
                        {
                            dr["Identificador"] = coincidenciaID.ToString();
                        }
                        dr["Tipo"] = "Cadena";
                    }
                    Regex expresionValor = new Regex("\\s*\\=+\\s*\\\"([\\w\\s\\d]{0,})\\\"\\s*");
                    MatchCollection coincidenciasValor = expresionValor.Matches(declaracion);
                    string temporalTXT = string.Empty;
                    if (coincidenciasValor.Count > 0)
                    {
                        foreach (Match coincidenciaValor in coincidenciasValor)
                        {
                            temporalTXT = string.Empty;
                            temporalTXT = coincidenciaValor.ToString();
                            temporalTXT = temporalTXT.Replace('=', ' ');
                            temporalTXT = temporalTXT.Replace(';', ' ');
                            dr["Valor"] = temporalTXT.Trim();
                        }
                    }
                    else
                    {
                        dr["Valor"] = "Error";
                    }
                    dt.Rows.Add(dr);
                    codigoUnico++;
                }

            }
            #endregion

            #region Decimales
            Regex expresionDec = new Regex(@"(\bdeci)\s*(\$+([\w\d]{1,}))\s*(\=)+\s*(([\d.]{1,})|\"".*\""?\s*\"")+\s*");
            MatchCollection coincidenciasDec = expresionDec.Matches(codigoOriginal);
            if (coincidenciasDec.Count > 0)
            {
                string declaracion = string.Empty;
                foreach (Match coincidenciaDec in coincidenciasDec)
                {
                    declaracion = coincidenciaDec.ToString();
                    Regex expresionIdentificador = new Regex(@"\$+([\w\d]{1,})+");
                    MatchCollection coincidenciasIdentificador = expresionIdentificador.Matches(declaracion);
                    dr = dt.NewRow();
                    if (coincidenciasIdentificador.Count > 0)
                    {
                        dr["Codigo"] = codigoUnico;
                        foreach (Match coincidenciaID in coincidenciasIdentificador)
                        {
                            dr["Identificador"] = coincidenciaID.ToString();
                        }
                        dr["Tipo"] = "Decimal";
                    }
                    Regex expresionValor = new Regex(@"\s*(\=)+\s*([\d.]{1,})+");
                    MatchCollection coincidenciasValor = expresionValor.Matches(declaracion);
                    string temporalDec = string.Empty;
                    if (coincidenciasValor.Count > 0)
                    {
                        foreach (Match coincidenciaValor in coincidenciasValor)
                        {
                            temporalDec = string.Empty;
                            temporalDec = coincidenciaValor.ToString();
                            temporalDec = temporalDec.Replace('=', ' ');
                            temporalDec = temporalDec.Replace(';', ' ');
                            dr["Valor"] = temporalDec.Trim();
                        }
                    }
                    else
                    {
                        dr["Valor"] = "Error";
                    }
                    dt.Rows.Add(dr);
                    codigoUnico++;
                }

            }
            #endregion

            return dt;
        }

        /// <summary>
        /// Método para determinar si el código contiene las palabras reservadas de inicio y fin.
        /// </summary>
        /// <param name="codigo">Código limpio</param>
        /// <returns>Falso en caso de la ausencia de las palabras</returns>
        private bool TieneInicioFin(string codigo)
        {
            bool resultado = false;
            bool resultadoIni = false;
            bool resultadoFin = false;
            //Regex expresion = new Regex(@"^\ninicio\b[\w\d\sáéíóúAÉÍÓÚÑñ\""'.,;_#=/*--+·()$!<>]{0,1000}\bfin$|" +
            //@"^inicio\b[\w\d\sáéíóúAÉÍÓÚÑñ\""'.,;_#=/*--+·()$!<>]{0,1000}\bfin$|" +
            //@"^\ninicio\b[\w\d\sáéíóúAÉÍÓÚÑñ\""'.,;_#=/*--+·()$!<>]{0,1000}\bfin\n$|" +
            //@"^inicio\b[\w\d\sáéíóúAÉÍÓÚÑñ\""'.,;_#=/*--+·()$!<>]{0,1000}\bfin\n$");
            //return expresion.IsMatch(codigo);
            Regex expresionInicio = new Regex(@"(\binicio\b)");
            Regex expresionFin = new Regex(@"(\bfin\b)");
            if (expresionInicio.IsMatch(codigo))
            {
                resultadoIni = true;
            }
            if (expresionFin.IsMatch(codigo))
            {
                resultadoFin = true;
            }
            if (resultadoIni&&resultadoFin)
            {
                resultado = true;
            }
            return resultado;
        }


        /// <summary>
        /// Método para eliminar los comentarios del código inicial.
        /// </summary>
        /// <param name="codigo">Codigo inicial</param>
        /// <returns>Código sin los comentarios</returns>
        private string LimpiarComentarios(string codigo)
        {
            return Regex.Replace(codigo, @"\#.*\#?\#", string.Empty);
        }

        #endregion
    }
}
