﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsAnalisisSintactico.cs
 * Descripcion: Clase con los componentes necesarios para iniciar el Análisis Sintáctico.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.IO;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Compilador.AdministracionSimbolos;
using Compilador.Errores;

namespace Compilador.Sintactico
{
    /// <summary>
    /// Clase con los componentes necesarios para iniciar el Análisis Sintáctico.
    /// </summary>
    public class clsAnalisisSintactico
    {
        #region Declaraciones

        private const string sintactico = "Sintáctico";

        #endregion

        #region Constructores

        /// <summary>
        /// Constructor
        /// </summary>
        public clsAnalisisSintactico() { }

        #endregion

        #region Métodos

        /// <summary>
        /// Analiza el código resultante en busca de errores sintácticos.
        /// </summary>
        /// <param name="rutaArchivo">Ruta del Código</param>
        /// <param name="codigoLimpio">Código Limpio</param>
        /// <param name="tablaSimbolos">Tabla con los identificadores</param>
        /// <returns>Retorna el listado de errores detectados</returns>
        public void AnalisisSintactico(string rutaArchivo, string codigoLimpio, DataTable tablaSimbolos)
        {
            string codigo = codigoLimpio;
            string cod = string.Empty;
            const string elInicio = "inicio";
            const string elFin = "fin";
            const string finSi = "finSi";
            const string finSino = "finSino";
            const string finMientras = "finMientras";
            const string finDesde = "finDesde";
            const string espera = "espera";
            int numeroLinea = 1;
            bool declaraciones=false, expresiones = false, entrada = false, salida = false, si = false, sino = false, mientras = false, desde = false;
            bool lineaRevizada = false;
            try
            {
                // Valido la existencia del archivo antes del análisis.
                if (File.Exists(rutaArchivo))
                {
                    StreamReader objLector = new StreamReader(rutaArchivo);
                    string linea = string.Empty;
                    // Recorro cada linea y esta se envía a todos los métodos de análisis de expresiones regulares.
                    while (linea != null)
                    {
                        linea = objLector.ReadLine();
                        if (!string.IsNullOrEmpty(linea))
                        {
                            #region Lineas que se descartan porque ya fueron validadas.
                            // Descarto cuyalquier linea de comentarios.
                            if (this.EsLineaComentarios(linea))
                            {
                                goto Salto;
                            }
                            // Palabra reservada inicio.
                            if (linea.Equals(elInicio))
                            {
                                goto Salto;
                            }
                            // Palabra reservada fin.
                            if (linea.Equals(elFin))
                            {
                                goto Salto;
                            }
                            // Palabra reservada espera.
                            if (linea.Equals(espera))
                            {
                                goto Salto;
                            }
                            // Palabra reservada finSi.
                            if (linea.Equals(finSi))
                            {
                                goto Salto;
                            }
                            // Palabra reservada finSino.
                            if (linea.Equals(finSino))
                            {
                                goto Salto;
                            }
                            // Palabra reservada finMientras.
                            if (linea.Equals(finMientras))
                            {
                                goto Salto;
                            }
                            // Palabra reservada finDesde.
                            if (linea.Equals(finDesde))
                            {
                                goto Salto;
                            }
                            #endregion

                            // Validación de declaraciones.
                            if (this.Declaraciones(linea, numeroLinea, tablaSimbolos))
                            {
                                declaraciones = true;
                                lineaRevizada = true;
                            }

                            // Expresiones de asignación basicas.
                            if (!lineaRevizada && this.Expresiones_Basicas(linea, numeroLinea, tablaSimbolos))
                            {
                                expresiones = true;
                                lineaRevizada = true;
                            }
                            // Entradas y en pantalla.
                            if (!lineaRevizada && this.Entrada_Pantalla(linea, numeroLinea, tablaSimbolos))
                            {
                                entrada = true;
                                lineaRevizada = true;
                            }
                            // Salidas en pantalla.
                            if (!lineaRevizada && this.Salida_Pantalla(linea, numeroLinea, tablaSimbolos))
                            {
                                salida = true;
                                lineaRevizada = true;
                            }
                            // Estructura Si.
                            if (!lineaRevizada && this.dectaSi(linea))
                            {
                                if (this.Si_finSi(codigo, numeroLinea, tablaSimbolos))
                                {
                                    si = true;
                                    lineaRevizada = true;
                                }
                            }
                            // Estructura Sino.
                            if (!lineaRevizada && this.dectaSino(linea))
                            {
                                if (this.Sino_finSino(codigo, numeroLinea))
                                {
                                    sino = true;
                                    lineaRevizada = true;
                                }
                            }
                            // Estructura Mientras.
                            if (!lineaRevizada && this.dectaMientras(linea))
                            {
                                if (this.Mientras_finMientras(codigo, numeroLinea, tablaSimbolos))
                                {
                                    mientras = true;
                                    lineaRevizada = true;
                                }
                            }
                            // Estructura Desde.
                            if (!lineaRevizada && this.dectaDesde(linea))
                            {
                                if (this.Desde_finDesde(codigo, numeroLinea, tablaSimbolos))
                                {
                                    desde = true;
                                    lineaRevizada = true;
                                }
                            }
                            // En caso de no encontrar una expresión que sea valida en la linea, se registra un error general. 
                            if (declaraciones.Equals(false) && expresiones.Equals(false) && entrada.Equals(false) && salida.Equals(false) && si.Equals(false) && sino.Equals(false) && mientras.Equals(false) && desde.Equals(false) /*&& inicio.Equals(false) && fin.Equals(false)*/)
                            {
                                clsFlujoErrores.NuevoError(sintactico, "Error no identificado en la expresión", numeroLinea.ToString());
                            }
                            declaraciones = false;
                            expresiones = false;
                            entrada = false;
                            salida = false;
                            si = false;
                            sino = false;
                            mientras = false;
                            desde = false;
                            lineaRevizada = false;

                        Salto:
                            cod = string.Empty;

                            numeroLinea++;
                        }
                    }
                    objLector.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Detecta la presencia de la expresion "Si" en la linea.
        /// </summary>
        /// <param name="linea">Linea de codigo</param>
        /// <returns>Retorna True en casa de encontrar la coincidencia</returns>
        private bool dectaSi(string linea)
        {
            return Regex.IsMatch(linea, @"(\bsi\b)");
        }

        /// <summary>
        /// Detecta la presencia de la expresion "Sino" en la linea.
        /// </summary>
        /// <param name="linea">Linea de codigo</param>
        /// <returns>Retorna True en casa de encontrar la coincidencia</returns>
        private bool dectaSino(string linea)
        {
            return Regex.IsMatch(linea, @"(\bsino\b)");
        }

        /// <summary>
        /// Detecta la presencia de la expresion "Mientras" en la linea.
        /// </summary>
        /// <param name="linea">Linea de codigo</param>
        /// <returns>Retorna True en casa de encontrar la coincidencia</returns>
        private bool dectaMientras(string linea)
        {
            return Regex.IsMatch(linea, @"(\bmientras\b)");
        }

        /// <summary>
        /// Detecta la presencia de la expresion "Desde" en la linea.
        /// </summary>
        /// <param name="linea">Linea de codigo</param>
        /// <returns>Retorna True en casa de encontrar la coincidencia</returns>
        private bool dectaDesde(string linea)
        {
            return Regex.IsMatch(linea, @"(\bdesde\b)");
        }

        /// <summary>
        /// Método para determinar si el código contiene las expresiones "si y finSi".
        /// </summary>
        /// <param name="codigo">Código limpio</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla de simbolos</param>
        /// <returns>True en caso de encontrar la expresión</returns>
        private bool Si_finSi(string codigo, int numeroLinea, DataTable tablaSimbolos)
        {
            bool expresionEncontrada = false;
            int contadorCoincidencias = 0;
            int posicionSi = 0;
            int posicionFinSi = 0;
            int[] arregloSi = new int[0];
            int[] arreglofinSi = new int[0];
            // Verifico existencia de "SI".
            Regex expresionSi = new Regex(@"\bsi\b(\s)*(\()+(\s)*((\$[\w\d]{1,})|[\d.]{1,})(\s)*(=|<|>)+(\s)*((\$[\w\d]{1,})|[\d.]{1,})(\))+(\s)*\bentonces\b(\s)*");
            MatchCollection coincidenciasSi = expresionSi.Matches(codigo);
            if (coincidenciasSi.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arregloSi = new int[coincidenciasSi.Count];
                foreach (Match coincidenciaSi in coincidenciasSi)
                {
                    posicionSi = coincidenciaSi.Index;
                    arregloSi[i] = posicionSi;
                    i++;
                    // Valido que cada identificador en la estructura ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidenciaSi.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
            }
            // Verifico existencia de "FINSI".
            Regex expresionfinSi = new Regex(@"\bfinSi\b");
            MatchCollection coincidenciasfinSi = expresionfinSi.Matches(codigo);
            if (coincidenciasfinSi.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arreglofinSi = new int[coincidenciasfinSi.Count];
                foreach (Match coincidenciafinSi in coincidenciasfinSi)
                {
                    posicionFinSi = coincidenciafinSi.Index;
                    arreglofinSi[i] = posicionFinSi;
                    i++;
                }
                expresionEncontrada = true;
            }
            // Pregunto si no existe la misma cantidad de elementos.
            if (!coincidenciasSi.Count.Equals(coincidenciasfinSi.Count))
            {
                if (coincidenciasfinSi.Count > coincidenciasSi.Count)
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques si-entonces/finSi, la estructura no esta definida correctamente (La expresión \"si-entonces\" es incorrecta!)", numeroLinea.ToString());
                }
                else
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques si-entonces/finSi, la estructura no esta definida correctamente (La expresión \"finSi\" no está definida o es incorrecta!)", numeroLinea.ToString());
                }
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Método para determinar si el código contiene las expresiones "sino y finSino".
        /// </summary>
        /// <param name="codigo">Código limpio</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <returns>True en caso de encontrar la expresión</returns>
        private bool Sino_finSino(string codigo, int numeroLinea)
        {
            bool expresionEncontrada = false;
            int posicionSi = 0;
            int posicionFinSi = 0;
            int[] arregloSi = new int[0];
            int[] arreglofinSi = new int[0];
            // Verifico existencia de "SI".
            Regex expresionSi = new Regex(@"\bsino\b");
            MatchCollection coincidenciasSi = expresionSi.Matches(codigo);
            if (coincidenciasSi.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arregloSi = new int[coincidenciasSi.Count];
                foreach (Match coincidenciaSi in coincidenciasSi)
                {
                    posicionSi = coincidenciaSi.Index;
                    arregloSi[i] = posicionSi;
                    i++;
                }
                expresionEncontrada = true;
            }
            // Verifico existencia de "FINSI".
            Regex expresionfinSi = new Regex(@"\bfinSino\b");
            MatchCollection coincidenciasfinSi = expresionfinSi.Matches(codigo);
            if (coincidenciasfinSi.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arreglofinSi = new int[coincidenciasfinSi.Count];
                foreach (Match coincidenciafinSi in coincidenciasfinSi)
                {
                    posicionFinSi = coincidenciafinSi.Index;
                    arreglofinSi[i] = posicionFinSi;
                    i++;
                }
                expresionEncontrada = true;
            }
            // Pregunto si no existe la misma cantidad de elementos.
            if (!coincidenciasSi.Count.Equals(coincidenciasfinSi.Count))
            {
                if (coincidenciasfinSi.Count > coincidenciasSi.Count)
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques sino/finSino, la estructura no esta delimitada correctamente (La expresión \"sino\" es incorrecta!)", numeroLinea.ToString());
                }
                else
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques sino/finSino, la estructura no esta delimitada correctamente (La expresión \"finSino\" no está definida o es incorrecta!)", numeroLinea.ToString());
                }
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Método para determinar si el código contiene las expresiones "mientras y finMientras".
        /// </summary>
        /// <param name="codigo">Código limpio</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla de simbolos</param>
        /// <returns>True en caso de encontrar la expresión</returns>
        private bool Mientras_finMientras(string codigo, int numeroLinea, DataTable tablaSimbolos)
        {
            bool expresionEncontrada = false;
            int contadorCoincidencias = 0;
            int posicionMientras = 0;
            int posicionFinMientras = 0;
            int[] arregloMientras = new int[0];
            int[] arreglofinMientras = new int[0];
            // Verifico existencia de "MIENTRAS".
            Regex expresionMientras = new Regex(@"\bmientras\b(\s)*(\()+(\s)*((\$[\w\d]{1,})|[\d.]{1,})(\s)*(=|<|>)+(\s)*((\$[\w\d]{1,})|[\d.]{1,})(\s)*(\))+(\s)*\bentonces\b(\s)*");
            MatchCollection coincidenciasMientras = expresionMientras.Matches(codigo);
            if (coincidenciasMientras.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arregloMientras = new int[coincidenciasMientras.Count];
                foreach (Match coincidenciaMientras in coincidenciasMientras)
                {
                    posicionMientras = coincidenciaMientras.Index;
                    arregloMientras[i] = posicionMientras;
                    i++;
                    // Valido que cada identificador en la estructura ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidenciaMientras.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
            }
            // Verifico existencia de "FINMIENTRAS".
            Regex expresionfinMientras = new Regex(@"\bfinMientras\b");
            MatchCollection coincidenciasfinMientras = expresionfinMientras.Matches(codigo);
            if (coincidenciasfinMientras.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arreglofinMientras = new int[coincidenciasfinMientras.Count];
                foreach (Match coincidenciafinMientras in coincidenciasfinMientras)
                {
                    posicionFinMientras = coincidenciafinMientras.Index;
                    arreglofinMientras[i] = posicionFinMientras;
                    i++;
                }
                expresionEncontrada = true;
            }
            // Pregunto si no existe la misma cantidad de elementos.
            if (!coincidenciasMientras.Count.Equals(coincidenciasfinMientras.Count))
            {
                if (coincidenciasfinMientras.Count > coincidenciasMientras.Count)
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques mientras-entonces/finMientras, la estructura no esta delimitada correctamente (La expresión \"mientras-entonces\" es incorrecta!)", numeroLinea.ToString());
                }
                else
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques mientras-entonces/finMientras, la estructura no esta delimitada correctamente (La expresión \"finMientras\" no está definida o es incorrecta!)", numeroLinea.ToString());
                }
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Método para determinar si el código contiene las expresiones "desde y finDesde".
        /// </summary>
        /// <param name="codigo">Código limpio</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla de simbolos</param>
        /// <returns>True en caso de encontrar la expresión</returns>
        private bool Desde_finDesde(string codigo, int numeroLinea, DataTable tablaSimbolos)
        {
            bool expresionEncontrada = false;
            int contadorCoincidencias = 0;
            int posicionDesde = 0;
            int posicionFinDesde = 0;
            int[] arregloDesde = new int[0];
            int[] arreglofinDesde = new int[0];
            // Verifico existencia de "DESDE".
            Regex expresionDesde = new Regex(@"\bdesde\b(\s)*(\()+(\s)*(\$[\w\d]{1,}|[\d.]{1,})(\s)*(\;)+(\s)*(\$[\w\d]{1,}|[\d.]{1,})(\s)*(=|<|>)+(\s)*(\$[\w\d]{1,}|[\d.]{1,})(\s)*(\;)(\s)*(\$[\w\d++]{1,})(\s)*(\))+(\s)*\bhacer\b(\s)*");
            MatchCollection coincidenciasDesde = expresionDesde.Matches(codigo);
            if (coincidenciasDesde.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arregloDesde = new int[coincidenciasDesde.Count];
                foreach (Match coincidenciaDesde in coincidenciasDesde)
                {
                    posicionDesde = coincidenciaDesde.Index;
                    arregloDesde[i] = posicionDesde;
                    i++;
                    // Valido que cada identificador en la estructura ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidenciaDesde.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
            }
            // Verifico existencia de "FINDESDE".
            Regex expresionfinDesde = new Regex(@"\bfinDesde\b");
            MatchCollection coincidenciasfinDesde = expresionfinDesde.Matches(codigo);
            if (coincidenciasfinDesde.Count > 0)
            {
                // Almaceno la posición de cada coincidencia.
                int i = 0;
                arreglofinDesde = new int[coincidenciasfinDesde.Count];
                foreach (Match coincidenciafinMientras in coincidenciasfinDesde)
                {
                    posicionFinDesde = coincidenciafinMientras.Index;
                    arreglofinDesde[i] = posicionFinDesde;
                    i++;
                }
                expresionEncontrada = true;
            }
            // Pregunto si no existe la misma cantidad de elementos.
            if (!coincidenciasDesde.Count.Equals(coincidenciasfinDesde.Count))
            {
                if (coincidenciasfinDesde.Count > coincidenciasDesde.Count)
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques desde-hacer/finDesde, la estructura no esta delimitada correctamente (La expresión \"desde-hacer\" es incorrecta!)", numeroLinea.ToString());
                }
                else
                {
                    clsFlujoErrores.NuevoError(sintactico, "Error en los bloques desde-hacer/finDesde, la estructura no esta delimitada correctamente (La expresión \"finDesde\" no está definida o es incorrecta!)", numeroLinea.ToString());
                }
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Método para validar el contenido de las declaraciones.
        /// </summary>
        /// <param name="linea">Linea a validar</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla con los identificadores</param>
        private bool Declaraciones(string linea, int numeroLinea, DataTable tablaSimbolos)
        {
            bool declaracionEncontrada = false;
            //int contadorCoincidencias = 0;
            // Valido el contenido de las expresiones.
            Regex expresionFinal = new Regex(@"((\bent)|(\btxt)|(\bdeci)) \$+([\w\d]{1,})\s*\=?\s*(([\w\d.]{1,})|\"".*\""?\s*\"")+\s*");
            // Lleno el listado de coincidencias.
            MatchCollection final = expresionFinal.Matches(linea);
            if (final.Count > 0)
            {
                declaracionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            return declaracionEncontrada;
        }

        /// <summary>
        /// Método para validar el contenido de las expresiones basicas.
        /// </summary>
        /// <param name="linea">Linea a validar</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla con los identificadores</param>
        private bool Expresiones_Basicas(string linea, int numeroLinea, DataTable tablaSimbolos)
        {
            bool expresionEncontrada = false;
            int contadorCoincidencias = 0;
            // Valido el contenido de las expresiones.
            Regex expresionFinal = new Regex(@"(\$[\w\d]{1,})\s*=\s*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")+(\s)*(\+|\-|\-|\*|\/)+(\s)*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")+(\s)*(\+|\-|\-|\*|\/)?(\s)*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")?(\s)*");
            // Lleno el listado de coincidencias.
            MatchCollection final = expresionFinal.Matches(linea);
            if (final.Count > 0)
            {
                foreach (Match coincidencia in final)
                {
                    // Valido que cada identificador en la expresión ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias>0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Método para validar las expresiones que requieren salidas de pantalla.
        /// </summary>
        /// <param name="linea">Código limpio</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla con los identificadores</param>
        private bool Salida_Pantalla(string linea, int numeroLinea, DataTable tablaSimbolos)
        {
            bool expresionEncontrada = false;
            int contadorCoincidencias = 0;
            // Valido el contenido de las expresiones.
            Regex expresionSalida = new Regex(@"\bpintar\b\s+((\$[\w\d]{1,})+(\.aTexto)*|\"".*\""?\s*\"")(\s)*\bfinPintar\b(\s)*");
            MatchCollection salida = expresionSalida.Matches(linea);
            // Valido el contenido de las expresiones.
            Regex expresionSalida2 = new Regex(@"\bpintar\b\s+((\"".*\""?\s*\"")(\s)*(\+)+(\s)*(\$[\w\d]{1,})(\.aTexto)*)(\s)*\bfinPintar\b(\s)*");
            MatchCollection salida2 = expresionSalida2.Matches(linea);
            if (salida.Count > 0)
            {
                foreach (Match coincidencia in salida)
                {
                    // Valido que cada identificador en la expresión ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            contadorCoincidencias = 0;
            if (salida2.Count > 0)
            {
                foreach (Match coincidencia in salida2)
                {
                    // Valido que cada identificador en la expresión ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Método para validar las expresiones que requieren salidas de pantalla.
        /// </summary>
        /// <param name="linea">Linea</param>
        /// <param name="numeroLinea">Número de Linea</param>
        /// <param name="tablaSimbolos">Tabla con los identificadores</param>
        private bool Entrada_Pantalla(string linea, int numeroLinea, DataTable tablaSimbolos)
        {
            bool expresionEncontrada = false;
            int contadorCoincidencias = 0;
            // Valido el contenido de las expresiones.
            Regex expresionEntero = new Regex(@"(\$[\w\d]{1,})+(\s)*(\=)+\s*(convertir)+(\.)+(aEntero\(leer\))");
            MatchCollection coleccionEntero = expresionEntero.Matches(linea);
            Regex expresionDecimal = new Regex(@"(\$[\w\d]{1,})+(\s)*(\=)+\s*(convertir)+(\.)+(aDecimal\(leer\))");
            MatchCollection coleccionDecimal = expresionDecimal.Matches(linea);
            Regex expresionTexto = new Regex(@"(\$[\w\d]{1,})+(\s)*(\=)+\s*(leer)+");
            MatchCollection coleccionTexto = expresionTexto.Matches(linea);
            if (coleccionEntero.Count > 0)
            {
                foreach (Match coincidencia in coleccionEntero)
                {
                    // Valido que cada identificador en la expresión ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            contadorCoincidencias = 0;
            if (coleccionDecimal.Count > 0)
            {
                foreach (Match coincidencia in coleccionDecimal)
                {
                    // Valido que cada identificador en la expresión ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            contadorCoincidencias = 0;
            if (coleccionTexto.Count > 0)
            {
                foreach (Match coincidencia in coleccionTexto)
                {
                    // Valido que cada identificador en la expresión ya halla sido declarado previamente.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Se recorre toda la columna de identificadores.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Se comparan las declaraciones.
                            if (simbolo["Identificador"].ToString().Equals(coinID.Value))
                            {
                                contadorCoincidencias++;
                            }
                            // Si encuentro una coincindencia salgo del recorrido.
                            if (contadorCoincidencias > 0)
                            {
                                break;
                            }
                        }
                        // En caso de no encontrar la declaración se registra el error.
                        if (contadorCoincidencias.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(sintactico, "El token " + coinID.ToString() + " no ha sido declarado aún!", numeroLinea.ToString());
                        }
                        contadorCoincidencias = 0;
                    }
                }
                expresionEncontrada = true;
                // Validación de fin de linea.
                this.Fin_Linea(linea, numeroLinea);
            }
            return expresionEncontrada;
        }

        /// <summary>
        /// Determina si la expresion contiene el simbolo de fin de linea (;).
        /// </summary>
        /// <param name="linea">Linea de codigo</param>
        /// <param name="numeroLinea">Numero de linea correspondiente</param>
        private void Fin_Linea(string linea, int numeroLinea)
        {
            if (!Regex.IsMatch(linea, @"(\B(\;)+|\b(\;)+)"))
            {
                clsFlujoErrores.NuevoError(sintactico, "La expresión no contiene el simbolo (;) de fin de linea", numeroLinea.ToString());
            }
        }

        /// <summary>
        /// Determino si la linea contiene comentarios.
        /// </summary>
        /// <param name="linea">Linea a validar</param>
        /// <returns>True en caso de entontrar la coincidencia</returns>
        private bool EsLineaComentarios(string linea)
        {
            return Regex.IsMatch(linea, @"\#.*\#?\#");
        }

        #endregion
    }
}
