﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsEjecutable.cs
 * Descripcion: Clase con los componentes necesarios para convertir el código original en un esamblado ejecutable.
 * Autor:       Rodrigo Solís Artavia.
 */
using System;
using System.CodeDom.Compiler;
using System.Data;
using System.Diagnostics;
using System.IO;
using Microsoft.CSharp;

namespace Compilador.Sintesis
{
    /// <summary>
    /// Clase con los componentes necesarios para convertir el código original en un esamblado ejecutable.
    /// </summary>
    public class clsEjecutable
    {
        #region Métodos
        /// <summary>
        /// Método que traduce el código de origen.
        /// </summary>
        /// <param name="nombre">Nombre para el ejecutable</param>
        /// <param name="tablaSimbolos">Tabla de simbolos a traducir</param>
        public void TraducirCodigo(string nombre, DataTable tablaSimbolos)
        {
            string codigoFinal = string.Empty;
            string simboloTraducido = string.Empty;
            string valor = string.Empty;
            string lineaBase1 = "using System;";
            string lineaBase2 = "using System.Collections.Generic;";
            string lineaBase3 = "using System.Text;";
            string lineaBase4 = "namespace " + nombre;
            string lineaBase5 = "{";
            string lineaBase6 = "class " + nombre;
            string lineaBase7 = "{";
            string lineaBase8 = "static void Main(string[] args)";
            string lineaBase9 = "{";
            string programalineaBase10 = "";
            string lineaBase11 = "}";
            string lineaBase12 = "}";
            string lineaBase13 = "}";

            try
            {
                // Recorro cada simbolo en la tabla generaral para que sea remplazado por codigo C#.
                foreach (DataRow linea in tablaSimbolos.Rows)
                {
                    valor = linea["Simbolo"].ToString();
                    if (valor != "inicio" && valor != "fin")
                    {
                        switch (valor)
                        {
                            case "ent":
                                simboloTraducido = valor.Replace("ent", "int ");
                                break;
                            case "deci":
                                simboloTraducido = valor.Replace("deci", "decimal ");
                                break;
                            case "txt":
                                simboloTraducido = valor.Replace("txt", "string ");
                                break;
                            case "si":
                                simboloTraducido = valor.Replace("si", "if");
                                break;
                            case "entonces":
                                simboloTraducido = valor.Replace("entonces", Environment.NewLine + "{" + Environment.NewLine);
                                break;
                            case "finSi":
                                simboloTraducido = valor.Replace("finSi", "}" + Environment.NewLine);
                                break;
                            case "sino":
                                simboloTraducido = valor.Replace("sino", "else" + Environment.NewLine + "{");
                                break;
                            case "finSino":
                                simboloTraducido = valor.Replace("finSino", "}" + Environment.NewLine);
                                break;
                            case "mientras":
                                simboloTraducido = valor.Replace("mientras", "while");
                                break;
                            case "finMientras":
                                simboloTraducido = valor.Replace("finMientras", "}" + Environment.NewLine);
                                break;
                            case "desde":
                                simboloTraducido = valor.Replace("desde", "for");
                                break;
                            case "hacer":
                                simboloTraducido = valor.Replace("hacer", Environment.NewLine + "{" + Environment.NewLine);
                                break;
                            case "finDesde":
                                simboloTraducido = valor.Replace("finDesde", "}" + Environment.NewLine);
                                break;
                            case "pintar":
                                simboloTraducido = valor.Replace("pintar", "Console.WriteLine(");
                                break;
                            case "finPintar":
                                simboloTraducido = valor.Replace("finPintar", ")");
                                break;
                            case "leer":
                                simboloTraducido = valor.Replace("leer", "Console.ReadLine()");
                                break;
                            case "convertir":
                                simboloTraducido = valor.Replace("convertir", "Parse");
                                break;
                            case "aTexto":
                                simboloTraducido = valor.Replace("aTexto", "ToString()");
                                break;
                            case "espera":
                                simboloTraducido = valor.Replace("espera", "Console.ReadLine();");
                                break;
                            case "aEntero":
                                simboloTraducido = valor.Replace("aEntero", "int");
                                break;
                            case "aDecimal":
                                simboloTraducido = valor.Replace("aDecimal", "decimal");
                                break;
                            default:
                                if (valor.Equals(";"))
                                {
                                    simboloTraducido = valor + Environment.NewLine;
                                }
                                if (valor.Contains("$"))
                                {
                                    simboloTraducido = valor.Replace("$", "");
                                }
                                else
                                {
                                    simboloTraducido = valor;
                                }
                                break;
                        }
                        programalineaBase10 = programalineaBase10 + simboloTraducido;
                    }

                }
                /* Ahora invierto el orden de los comandos de coversion entre tipos para que coincidan sintacticamente con C#.
                     * Ejemplo: Lenguaje RSA -> convertir.aDecimal por aDecimal.convertir
                     *          Lenguaje C#  -> Parse.decimal a decimal.Parce
                     * */
                programalineaBase10 = programalineaBase10.Replace("Parse.decimal", "decimal.Parse");
                programalineaBase10 = programalineaBase10.Replace("Parse.int", "int.Parse");
                // Ensablaje de la estructura basica del código C#.
                codigoFinal = lineaBase1 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase2 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase3 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase4.Trim() + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase5 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase6.Trim() + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase7 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase8 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase9 + Environment.NewLine;
                codigoFinal = codigoFinal + programalineaBase10 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase11 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase12 + Environment.NewLine;
                codigoFinal = codigoFinal + lineaBase13 + Environment.NewLine;
                this.Compilar(nombre, codigoFinal);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// Método que toma el codigo traducido y genera el esamblado ejecutable.
        /// </summary>
        /// <param name="nombre">Nombre para el ejecutable</param>
        /// <param name="programa">Codigo a ensamblar</param>
        private void Compilar(string nombre, string programa)
        {
            try
            {
                CSharpCodeProvider proveedor = new CSharpCodeProvider();
                ICodeCompiler icc = proveedor.CreateCompiler();
                string salida = nombre + ".exe";
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = salida;
                CompilerResults resultados = icc.CompileAssemblyFromSource(parameters, programa);
                Process.Start(salida);
                salida = salida.Replace(".exe", ".txt");
                this.GuardarArchivoTexto(salida, programa);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Guardo el código traducido en un archivo de texto.
        /// </summary>
        /// <param name="elcodigo">Nombre del archivo</param>
        /// <param name="elcodigo">Código traducido a guardar</param>
        private void GuardarArchivoTexto(string nombre, string programa)
        {
            StreamWriter escribe;
            escribe = new StreamWriter(nombre);
            escribe.WriteLine(programa);
            escribe.Close();
        }

        #endregion
    }
}
