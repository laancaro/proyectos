﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsLeeTabla.cs
 * Descripcion: Clase para recuperar el listado de palabras reservadas del lenguaje.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace Compilador.AdministracionSimbolos
{
    /// <summary>
    /// Clase para recuperar el listado de palabras reservadas del lenguaje.
    /// </summary>
    public static class clsLeeTabla
    {
        #region Declaraciones

        //private static string id, elemento, tipo;
        private static List<clsSimbolos> listaSimbolos;

        #endregion

        #region Métodos
        /// <summary>
        /// Método para leer el archivo XML con las lista de palabras base.
        /// </summary>
        /// <returns>Lista del tipo clsSimbolos</returns>
        public static List<clsSimbolos> LeerTabla()
        {
            listaSimbolos = new List<clsSimbolos>();
            try
            {
                XmlDocument xdoc = new XmlDocument();
                xdoc.Load("tabla.xml");
                XmlNodeList tabla = xdoc.GetElementsByTagName("Tabla");
                XmlNodeList simbolos = ((XmlElement)tabla[0]).GetElementsByTagName("Simbolo");
                foreach (XmlElement nodo in simbolos)
                {
                    int i = 0;
                    clsSimbolos simb = new clsSimbolos();
                    XmlNodeList id = nodo.GetElementsByTagName("ID");
                    XmlNodeList elemento = nodo.GetElementsByTagName("Elemento");
                    XmlNodeList atributo = nodo.GetElementsByTagName("Atributo");
                    XmlNodeList tipo = nodo.GetElementsByTagName("Tipo");
                    string x = id[i].InnerText;
                    simb.ID = int.Parse(id[i].InnerText);
                    simb.Elemento = elemento[i].InnerText;
                    simb.Atributo = atributo[i].InnerText;
                    simb.Tipo = tipo[i++].InnerText;
                    listaSimbolos.Add(simb);
                    

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listaSimbolos;
        }

        #endregion
    }
}
