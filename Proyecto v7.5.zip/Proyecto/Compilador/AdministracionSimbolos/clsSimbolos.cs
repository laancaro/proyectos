﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsSimbolos.cs
 * Descripcion: Clase para recuperar el listado de palabras reservadas del lenguaje.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compilador.AdministracionSimbolos
{
    /// <summary>
    /// 
    /// </summary>
    public class clsSimbolos
    {
        #region Declaraciones

        private int id;
        private string elemento, tipo, atributo;

        #endregion

        #region Contructores

        public clsSimbolos()
        {
            id = 0;
            elemento = string.Empty;
            tipo = string.Empty;
            atributo = string.Empty;
        }

        #endregion

        #region Propiedades

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Elemento
        {
            get { return elemento; }
            set { elemento = value; }
        }

        public string Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public string Atributo
        {
            get { return atributo; }
            set { atributo = value; }
        }

        #endregion

    }
}
