﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsFlujoErrores.cs
 * Descripcion: Clase para la administración de mensajes de error.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.IO;

namespace Compilador.Errores
{
    /// <summary>
    /// Clase para la administración de mensajes de error.
    /// </summary>
    public static class clsFlujoErrores
    {
       #region Declaraciones

        //private string tipoError;
        //private string ErrMensaje;
        //private string MsgDefault = string.Empty;
        //private string ErrDefault = string.Empty;

        #endregion

       #region Constructores
        // Constructor por defecto.
        //public clsFlujoErrores() { }

       // Constructor que acepta una excepcion y un mensaje.
        //public clsFlujoErrores(string strTipo, string strMensaje, string strUbicacion)
        //{ 
        //    SeleccionError(strTipo, strMensaje, strUbicacion); 
        //}

        #endregion

       #region Propiedades
        // Redefino esta propiedad con el mensaje imprimible adecuado.
       //override public string Message
       //{
       //    get
       //    {
       //        return ErrMensaje;
       //    }
       //}
        
        #endregion

       #region Métodos

        /// <summary>
        /// Método para escribir un nuevo error encontrado durante el proceso de compilación en el archivo de registros de compilación.
        /// </summary>
        /// <param name="tipoError">Tipo de error segun la capa de analisis</param>
        /// <param name="mensaje">Mensaje con el detalle del error</param>
        /// <param name="ubicacion">Posicion en el código</param>
        public static void NuevoError(string tipoError, string mensaje, string ubicacion)
        {
            try
            {
                FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\RegistroCompilacion.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);

                sw.WriteLine(" ");
                sw.WriteLine("----------------------REGISTRO DE COMPILACION-----------------------------");
                sw.WriteLine("FECHA...........................:" + DateTime.Now);
                sw.WriteLine("UBICACION.......................:" + ubicacion);
                sw.WriteLine("TIPO DE ERROR...................:" + tipoError);
                sw.WriteLine("MENSAJE.........................:" + mensaje);
                sw.WriteLine("----------------------FIN DE REGISTRO DE COMPILACION-----------------------------");
                sw.WriteLine(" ");
                sw.Flush();
                sw.Close();
            }
            catch (Exception)
            {
                throw;
            }

        }

       #endregion
    }
}
