﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       clsAnalisisSemantico.cs
 * Descripcion: Clase con los componentes necesarios para iniciar el Análisis Semantico.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.Data;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Compilador.AdministracionSimbolos;
using Compilador.Errores;

namespace Compilador.Semantico
{
    /// <summary>
    /// Clase con los componentes necesarios para iniciar el Análisis Semántico.
    /// </summary>
    public class clsAnalisisSemantico
    {
        #region Declaraciones

        private const string semantico = "Semántico";

        #endregion

        #region Constructores

        /// <summary>
        /// Constructor
        /// </summary>
        public clsAnalisisSemantico() { }

        #endregion

        #region Métodos

        /// <summary>
        /// Analiza el código resultante en busca de errores semánticos.
        /// </summary>
        /// <param name="codigoLimpio">Codigo inicial</param>
        /// <param name="tablaSimbolos">Tabla con los identificadores</param>
        /// <returns>Retorna el listado de errores detectados</returns>
        public string AnalisisSemantico(string codigoLimpio, DataTable tablaSimbolos)
        {
            try
            {
                this.ValidarDeclaraciones(tablaSimbolos);
                this.ValidarExpresiones(codigoLimpio, tablaSimbolos);
                this.ValidarConversiones(codigoLimpio, tablaSimbolos);
                this.ValidarCondiciones(codigoLimpio, tablaSimbolos);
                this.ValidarSalidasPantalla(codigoLimpio, tablaSimbolos);
            }
            catch (Exception)
            {
                throw;
            }
            return codigoLimpio;
        }

        /// <summary>
        /// Método para validar los tipos en las declaraciones de identificadores.
        /// </summary>
        /// <param name="tablaSimbolos">tabla con simbolos</param>
        private void ValidarDeclaraciones(DataTable tablaSimbolos)
        {
            foreach (DataRow fila in tablaSimbolos.Rows)
            {
                // Verificación de tipos declarados como ent.
                if (fila["Tipo"].ToString().Equals("Entero"))
                {
                    if (fila["Valor"].ToString().Equals("Error"))
                    {
                        clsFlujoErrores.NuevoError(semantico, "El tipo ent declarado para el identificador " + fila["Identificador"].ToString() + " no concuerda con su valor", "2");
                    }
                }
                // Verificación de tipos declarados como txt.
                if (fila["Tipo"].ToString().Equals("Cadena"))
                {
                    if (fila["Valor"].ToString().Equals("Error"))
                    {
                        clsFlujoErrores.NuevoError(semantico, "El tipo txt declarado para el identificador " + fila["Identificador"].ToString() + " no concuerda con su valor", "2");
                    }
                }
                // Verificación de tipos declarados como dec.
                if (fila["Tipo"].ToString().Equals("Decimal"))
                {
                    if (fila["Valor"].ToString().Equals("Error"))
                    {
                        clsFlujoErrores.NuevoError(semantico, "El tipo deci declarado para el identificador " + fila["Identificador"].ToString() + " no concuerda con su valor", "2");
                    }
                }
            }

        }

        /// <summary>
        /// Método para validar los tipos en las expresiones.
        /// </summary>
        /// <param name="codigo">Código Inicial</param>
        /// <param name="tablaSimbolos">Tabla con los simbolos detectados</param>
        private void ValidarExpresiones(string codigo, DataTable tablaSimbolos)
        {
            string valorBase = string.Empty;
            string tipoBase = string.Empty;
            Regex expresion = new Regex(@"(\$[\w\d]{1,})\s*=\s*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")+(\s)*(\+|\-|\-|\*|\/)+(\s)*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")+(\s)*(\+|\-|\-|\*|\/)?(\s)*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")?(\s)*");
            // Lleno el listado de coincidencias.
            MatchCollection coleccion = expresion.Matches(codigo);
            if (coleccion.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})\s*\=");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Quito el simbo '=' y los espacios.
                        string temporal = coinID.Value.Replace('=', ' ');
                        temporal = temporal.Trim();
                        /* Se recorre toda la columna de identificadores para determinar cuál es el id con el tipo de valor base.
                         * Este valor base es el que voy a comparar con los proximos ids y valores que esten despues del simbolo '='. 
                         */
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            if (temporal.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                            }
                        }
                    }
                    // Separo la expresion despues del simbolo '='.
                    Regex declaracionesSecundarias = new Regex(@"=\s*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")+(\s)*(\+|\-|\-|\*|\/)+(\s)*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")+(\s)*(\+|\-|\-|\*|\/)?(\s)*(\$[\w\d]{1,}|[\d.]{1,}|\"".*\""?\s*\"")?(\s)*");
                    MatchCollection coincidenciasSecundarias = declaracionesSecundarias.Matches(coincidencia.Value);
                    if (coincidenciasSecundarias.Count > 0)
                    {
                        foreach (Match coin_seg in coincidenciasSecundarias)
                        {
                            // Selección y comparacion de tipo para cada id encontrado en la expresión.
                            Regex expTipoID = new Regex(@"(\$[\w\d]{1,})");
                            MatchCollection coincidenciasTipoID = expTipoID.Matches(coin_seg.Value);
                            if (coincidenciasTipoID.Count > 0)
                            {
                                // Recorro cada coincidencia.
                                foreach (Match itemID in coincidenciasTipoID)
                                {
                                    // Recorro cada id en la tabla de simbolos.
                                    foreach (DataRow simbolo in tablaSimbolos.Rows)
                                    {
                                        // Comparación contra cada id en la tabla de simbolos.
                                        if (itemID.Value.Equals(simbolo["Identificador"]))
                                        {
                                            // Segun el tipo base detectado asi sera la comparacion de tipos numericos.
                                            switch (tipoBase)
                                            {
                                                case "Texto":
                                                    // Valido el tipo de dato, sino concuerda entonces se genera un error semántico.
                                                    if (!simbolo["Tipo"].Equals("Texto"))
                                                    {
                                                        clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el identificador " + itemID.Value, "6");
                                                    }
                                                    break;
                                                case "Decimal":
                                                    // Valido el tipo de dato, sino concuerda entonces se genera un error semántico.
                                                    if (!simbolo["Tipo"].Equals("Entero") && !simbolo["Tipo"].Equals("Decimal"))
                                                    {
                                                        clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el identificador " + itemID.Value, "6");
                                                    }
                                                    break;
                                                case "Entero":
                                                    // Valido el tipo de dato, sino concuerda entonces se genera un error semántico.
                                                    if (!simbolo["Tipo"].Equals("Entero"))
                                                    {
                                                        clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el identificador " + itemID.Value, "6");
                                                    }
                                                    break;
                                                default:
                                                    break;
                                            }
                                        }
                                    }
                                }
                            }
                            // Determino posibles valores numericos en la expresión.
                            int resultadoConversion = 0;
                            Regex expTipoNumero = new Regex(@"[\d.]{1,}");
                            MatchCollection coincidenciasTipoNumero = expTipoNumero.Matches(coincidencia.Value);
                            if (coincidenciasTipoNumero.Count > 0)
                            {
                                // Segun el tipo base detectado asi sera la comparacion de tipos numericos.
                                switch (tipoBase)
                                {
                                        // Si la base es Texto automaticamente sabemos que hay un error semámtico.
                                    case "Texto":
                                        foreach (Match itemNumero in coincidenciasTipoNumero)
                                        {
                                            clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el valor declarado " + itemNumero.Value, "6");
                                        }
                                        break;
                                        // Si la base es Decimal, los valores declarados del tipo deci y el tipo ent no tienen problemas de conversión, asi que se omiten.
                                    case"Decimal":
                                        break;
                                        /* Si la base es entera, se debe validar que cualquier valor declarado pueda ser convertido previamente a entero. 
                                         * Por ejemplo si mi valor declarado es del tipo decimal, debe verificar que pueda convertirlo a entero, de lo contrario, genero un nuevo error semántico.
                                         */
                                    case "Entero":
                                        foreach (Match itemNumero in coincidenciasTipoNumero)
                                        {
                                            if (int.TryParse(itemNumero.Value, out resultadoConversion))
                                            {
                                                resultadoConversion = 0;
                                            }
                                            else
                                            {
                                                clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el valor declarado " + itemNumero.Value, "6");
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
                            // Determino posibles valores de texto en la expresión.
                            Regex expTipoTexto = new Regex(@"\""([.\w\s\d]{1,})?\""");
                            MatchCollection coincidenciasTipoTexto = expTipoTexto.Matches(coincidencia.Value);
                            if (coincidenciasTipoTexto.Count > 0)
                            {
                                // Segun el tipo base detectado asi sera la comparación de las cadenas declaradas.
                                switch (tipoBase)
                                {
                                    // Si la base y los valores son del tipo texto entoces omito la comprobación.
                                    case "Texto":
                                        break;
                                        // Si la base es Decimal genero un error semántico.
                                    case "Decimal":
                                        foreach (Match itemTexto in coincidenciasTipoTexto)
                                        {
                                            clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el valor declarado " + itemTexto.Value, "6");
                                        }
                                        break;
                                    // Si la base es Entero genero un error semántico.
                                    case "Entero":
                                        foreach (Match itemTexto in coincidenciasTipoTexto)
                                        {
                                            clsFlujoErrores.NuevoError(semantico, "La expresión \"" + coincidencia.Value + "\" contiene un error de tipos en el valor declarado " + itemTexto.Value, "6");
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Método para validar los tipos en las conversiones.
        /// </summary>
        /// <param name="codigo">Código Inicial</param>
        /// <param name="tablaSimbolos">Tabla con los simbolos detectados</param>
        private void ValidarConversiones(string codigo, DataTable tablaSimbolos)
        {
            // Conversiones a enteros.
            string valorBase = string.Empty;
            string tipoBase = string.Empty;
            Regex expresion = new Regex(@"(\$[\w\d]{1,})+(\s)*(\=)+\s*(convertir)+(\.)+(aEntero\(leer\))");
            // Lleno el listado de coincidencias.
            MatchCollection coleccion = expresion.Matches(codigo);
            if (coleccion.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})\s*\=");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Quito el simbo '=' y los espacios.
                        string temporal = coinID.Value.Replace('=', ' ');
                        temporal = temporal.Trim();
                        /* Se recorre toda la columna de identificadores para determinar cuál es el id con el tipo de valor base.
                         * Este valor base es el que voy a comparar con los proximos ids y valores que esten despues del simbolo '='. 
                         */
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            if (temporal.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                            }
                        }
                    }
                    if (!tipoBase.Equals("Entero"))
                    {
                        clsFlujoErrores.NuevoError(semantico, "No se pude convertir del tipo entero al tipo " + tipoBase + " en la expresión \"" + coincidencia.Value + "\"", "6");
                    }
                }
            }
            // Conversiones a decimales.
            valorBase = string.Empty;
            tipoBase = string.Empty;
            expresion = new Regex(@"(\$[\w\d]{1,})+(\s)*(\=)+\s*(convertir)+(\.)+(aDecimal\(leer\))");
            // Lleno el listado de coincidencias.
            coleccion = expresion.Matches(codigo);
            if (coleccion.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})\s*\=");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Quito el simbo '=' y los espacios.
                        string temporal = coinID.Value.Replace('=', ' ');
                        temporal = temporal.Trim();
                        /* Se recorre toda la columna de identificadores para determinar cuál es el id con el tipo de valor base.
                         * Este valor base es el que voy a comparar con los proximos ids y valores que esten despues del simbolo '='. 
                         */
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            if (temporal.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                            }
                        }
                    }
                    if (!tipoBase.Equals("Decimal"))
                    {
                        clsFlujoErrores.NuevoError(semantico, "No se pude convertir del tipo decimal al tipo " + tipoBase + " en la expresión \"" + coincidencia.Value + "\"", "6");
                    }
                }
            }
            // Conversiones a texto.
            valorBase = string.Empty;
            tipoBase = string.Empty;
            expresion = new Regex(@"(\$[\w\d]{1,})+(\s)*(\=)+\s*(leer)+");
            // Lleno el listado de coincidencias.
            coleccion = expresion.Matches(codigo);
            if (coleccion.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})\s*\=");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Quito el simbo '=' y los espacios.
                        string temporal = coinID.Value.Replace('=', ' ');
                        temporal = temporal.Trim();
                        /* Se recorre toda la columna de identificadores para determinar cuál es el id con el tipo de valor base.
                         * Este valor base es el que voy a comparar con los proximos ids y valores que esten despues del simbolo '='. 
                         */
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            if (temporal.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                            }
                        }
                    }
                    if (!tipoBase.Equals("Texto"))
                    {
                        clsFlujoErrores.NuevoError(semantico, "No se pude convertir del tipo Texto al tipo " + tipoBase + " en la expresión \"" + coincidencia.Value + "\"", "6");
                    }
                }
            }
        }

        /// <summary>
        /// Método para validar los tipos en las condiciones.
        /// </summary>
        /// <param name="codigo">Código Inicial</param>
        /// <param name="tablaSimbolos">Tabla con los simbolos detectados</param>
        private void ValidarCondiciones(string codigo, DataTable tablaSimbolos)
        {
            string valorBase = string.Empty;
            string tipoBase = string.Empty;
            Regex expresion = new Regex(@"((\()(\s)*\$[\w\d]{1,}|[\d.]{1,})(\s)*(=|<|>)+(\s)*(\$[\w\d]{1,}|[\d.]{1,}(\s)*(\)))");
            // Lleno el listado de coincidencias.
            MatchCollection coleccion = expresion.Matches(codigo);
            if (coleccion.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            // Recorro cada simbolo hasta determinar el tipo base.
                            if (coinID.Value.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                            }
                        }
                        if (tipoBase.Equals("Texto"))
                        {
                            clsFlujoErrores.NuevoError(semantico, "La condición \"" + coincidencia.Value + "\" contiene un error de tipos en el identificador " + coinID.Value, "6");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Método para validar los tipos en las salidas de pantalla.
        /// </summary>
        /// <param name="codigo">Código Inicial</param>
        /// <param name="tablaSimbolos">Tabla con los simbolos detectados</param>
        private void ValidarSalidasPantalla(string codigo, DataTable tablaSimbolos)
        {
            string valorBase = string.Empty;
            string tipoBase = string.Empty;
            string idtemporal = string.Empty;
            Regex expresion = new Regex(@"\bpintar\b\s+((\"".*\""?\s*\"")(\s)*(\+)+(\s)*(\$[\w\d]{1,})(\.aTexto)*)(\s)*\bfinPintar\b(\s)*");
            // Lleno el listado de coincidencias.
            MatchCollection coleccion = expresion.Matches(codigo);
            if (coleccion.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Recorro la tabla de simbolos hasta encontrar el valor base del id.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            if (coinID.Value.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                                idtemporal = coinID.Value;
                            }
                        }
                    }
                    // Busco la extensión de la propiedad "aTexto"
                    Regex exprop = new Regex(@"(\.aTexto)");
                    MatchCollection concidenciasprop = exprop.Matches(coincidencia.Value);
                    // Se recorren todos los elementos que coinciden.
                    if (tipoBase.Equals("Entero") || tipoBase.Equals("Decimal"))
                    {
                        if (concidenciasprop.Count.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(semantico, "Error de tipos de datos en la expresión \"" + coincidencia.Value + "\", se requiere utilizar la propietad \".aTexto\" despues del identificador " + idtemporal, "6");
                        }
                    }
                    if (tipoBase.Equals("Texto"))
                    {
                        if (concidenciasprop.Count>0)
                        {
                            clsFlujoErrores.NuevoError(semantico, "No es necesario utilizar la propietad \".aTexto\" en el identificador " + idtemporal +" ya que es del tipo "+ tipoBase, "6");
                        }
                    }
                }
            }
            // Validación de expresion de salida alterna.
            valorBase = string.Empty;
            tipoBase = string.Empty;
            idtemporal = string.Empty;
            Regex expresion2 = new Regex(@"\bpintar\b\s+(\$[\w\d]{1,})+(\.aTexto)*(\s)*\bfinPintar\b(\s)*");
            // Lleno el listado de coincidencias.
            MatchCollection coleccion2 = expresion2.Matches(codigo);
            if (coleccion2.Count > 0)
            {
                // Recorro cada expresión encontrada.
                foreach (Match coincidencia in coleccion2)
                {
                    // Busco el valor destino.
                    Regex ids = new Regex(@"(\$[\w\d]{1,})");
                    MatchCollection concidenciasID = ids.Matches(coincidencia.Value);
                    // Se recorren todos los ids que coinciden.
                    foreach (Match coinID in concidenciasID)
                    {
                        // Recorro la tabla de simbolos hasta encontrar el valor base del id.
                        foreach (DataRow simbolo in tablaSimbolos.Rows)
                        {
                            if (coinID.Value.Equals(simbolo["Identificador"]))
                            {
                                valorBase = simbolo["Valor"].ToString();
                                tipoBase = simbolo["Tipo"].ToString();
                                idtemporal = coinID.Value;
                            }
                        }
                    }
                    // Busco la extensión de la propiedad "aTexto"
                    Regex exprop = new Regex(@"(\.aTexto)");
                    MatchCollection concidenciasprop = exprop.Matches(coincidencia.Value);
                    // Se recorren todos los elementos que coinciden.
                    if (tipoBase.Equals("Entero") || tipoBase.Equals("Decimal"))
                    {
                        if (concidenciasprop.Count.Equals(0))
                        {
                            clsFlujoErrores.NuevoError(semantico, "Error de tipos de datos en la expresión \"" + coincidencia.Value + "\", se requiere utilizar la propietad \".aTexto\" despues del identificador " + idtemporal, "6");
                        }
                    }
                    if (tipoBase.Equals("Texto"))
                    {
                        if (concidenciasprop.Count > 0)
                        {
                            clsFlujoErrores.NuevoError(semantico, "No es necesario utilizar la propietad \".aTexto\" en el identificador " + idtemporal + " ya que es del tipo " + tipoBase, "6");
                        }
                    }
                }
            }

        }

        #endregion
    }
}
