﻿/*
 * UAM - MODELOS DE PROGRAMACIÓN - COMPILADOR
 * Clase:       frmInicio.cs
 * Descripcion: Interfaz de inicio.
 * Autor:       Rodrigo Solís Artavia.
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;
using System.Drawing;
using Compilador.AdministracionSimbolos;
using Compilador.Lexico;
using Compilador.Sintactico;
using Compilador.Semantico;
using Compilador.Sintesis;


namespace Compilador.IDE
{
    /// <summary>
    /// Interfaz de Inicio.
    /// </summary>
    public partial class frmInicio : Form
    {
        #region Declaraciones

        private string rutaArchivoGlobal;
        private List<clsSimbolos> listaSimbolos;
        private DataTable dt = new DataTable();
        private DataTable dtSimbolos = new DataTable();
        private string codigoPorProcesar = string.Empty;
        private ArrayList arrTexto = new ArrayList();

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public frmInicio()
        {
            InitializeComponent();
        }

        #endregion
        
        #region Métodos
        /// <summary>
        /// Limpia las cajas de texto a su estado original.
        /// </summary>
        private void LimpiarTexto()
        {
            txtCodigoInicial.Clear();
            txtInformacion.Clear();
            dgvTablaTokens.DataSource = null;
            dgvTablaSimbolos.DataSource = null;
            rutaArchivoGlobal = string.Empty;
            codigoPorProcesar = string.Empty;
            arrTexto.Clear();
        }

        /// <summary>
        /// Abre un archivo (.txt) con el codigo inicial.
        /// </summary>
        /// <param name="rutaArchivo"></param>
        private void LeerArchivotxt(string rutaArchivo)
        {
            this.LimpiarTexto();
            if (File.Exists(rutaArchivo))
            {
                StreamReader objLector = new StreamReader(rutaArchivo);
                string linea = "";
                ArrayList arrTexto = new ArrayList();

                while (linea != null)
                {
                    linea = objLector.ReadLine();
                    if (linea != null)
                        arrTexto.Add(linea);
                }
                objLector.Close();

                foreach (string salida in arrTexto)
                {
                    txtCodigoInicial.Text = txtCodigoInicial.Text + salida + "\n";
                }
            }

        }

        /// <summary>
        /// Carga en memoria el listado de palabras reservadas desde un archivo (.xml).
        /// </summary>
        private void CargarTabla()
        {
            try
            {
                listaSimbolos = new List<clsSimbolos>();
                listaSimbolos = clsLeeTabla.LeerTabla();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        /// <summary>
        /// Invoca la llamada de analisis lexico desde la capa respectiva.
        /// </summary>
        private void AnalisisLexico()
        {
            try
            {
                if (this.listaSimbolos.Count > 0)
                {
                    clsAnalisisLexico cal = new clsAnalisisLexico();
                    codigoPorProcesar = cal.AnalisisLexico(this.txtCodigoInicial.Text.Trim());
                    dt = cal.GenerarTablaTokens(codigoPorProcesar.ToCharArray(), this.listaSimbolos);
                    this.dgvTablaTokens.DataSource = null;
                    this.dgvTablaTokens.DataSource = dt;
                    dtSimbolos = cal.GenerarTablaSimbolos(codigoPorProcesar);
                    this.dgvTablaSimbolos.DataSource = null;
                    this.dgvTablaSimbolos.DataSource = dtSimbolos;
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        /// <summary>
        /// Invoca la llamada de analisis sintactico desde la capa respectiva.
        /// </summary>
        private void AnalisisSintactico() 
        {
            //string codigoLimpio = string.Empty;
            try
            {
                if (this.listaSimbolos.Count > 0)
                {
                    clsAnalisisSintactico cas = new clsAnalisisSintactico();
                    cas.AnalisisSintactico(this.rutaArchivoGlobal, codigoPorProcesar, dtSimbolos);
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        /// <summary>
        /// Invoca la llamada de analisis sintactico desde la capa respectiva.
        /// </summary>
        private void AnalisisSemantico()
        {
            string codigoLimpio = string.Empty;
            try
            {
                if (this.listaSimbolos.Count > 0)
                {
                    clsAnalisisSemantico cas = new clsAnalisisSemantico();
                    cas.AnalisisSemantico(this.txtCodigoInicial.Text.Trim(), dtSimbolos);
                    if (this.dgvTablaSimbolos.Rows.Count > 0)
                    {
                        this.RecuperarErrores();
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Recupera el lista de errores encontrados durante el proceso de compilación desde el archivo de registros de compilación.
        /// </summary>
        private void RecuperarErrores()
        {
            try
            {
                if (File.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "\\RegistroCompilacion.txt"))
                {
                    StreamReader objLector = new StreamReader(System.AppDomain.CurrentDomain.BaseDirectory + "\\RegistroCompilacion.txt");
                    string linea = "";
                    arrTexto = new ArrayList();

                    while (linea != null)
                    {
                        linea = objLector.ReadLine();
                        if (linea != null)
                            arrTexto.Add(linea);
                    }
                    objLector.Close();

                    foreach (string salida in arrTexto)
                    {
                        txtInformacion.Text = txtInformacion.Text + salida + "\n";
                    }
                    if (txtInformacion.Text.Equals(string.Empty))
                    {
                        txtInformacion.Text = "========== Modo de Compilación:  Exito!!! ==========";
                    }
                }
                else
                {
                    if (txtInformacion.Text.Equals(string.Empty))
                    {
                        txtInformacion.Text = "========== Modo de Compilación:  Exito!!! ==========";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: No es posible recuperar el registro de compilación\nDetalle: "+ex.Message, "IDE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Elimina cualquier archivo de compilación existente previo a un nuevo proceso de compilación.
        /// </summary>
        private void EliminarRegistrosCompilacion()
        {
            if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\RegistroCompilacion.txt"))
            {
                try
                {
                    File.Delete(AppDomain.CurrentDomain.BaseDirectory + "\\RegistroCompilacion.txt");
                }
                catch (IOException)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Guardo el código que este en pantalla en el momento mediante un cuadro de dialogo.
        /// </summary>
        /// <param name="elcodigo">Código fuente a guardar</param>
        private void GuardarArchivoTexto(string elcodigo)
        {
            string[] arregloTexto=this.txtCodigoInicial.Lines;
            Stream miCodigo;
            StreamWriter escribe;
            SaveFileDialog dialogoGuardar = new SaveFileDialog();
            dialogoGuardar.Filter = "txt files (*.txt)|*.txt";
            dialogoGuardar.FilterIndex = 1;
            dialogoGuardar.RestoreDirectory = true;

            if (dialogoGuardar.ShowDialog().Equals(DialogResult.OK))
            {
                if ((miCodigo = dialogoGuardar.OpenFile()) != null)
                {
                    escribe = new StreamWriter(miCodigo, System.Text.Encoding.Unicode);
                    foreach (string linea in arregloTexto)
                    {
                        if (!string.IsNullOrEmpty(linea))
                        {
                            escribe.WriteLine(linea);
                        }
                    }
                    escribe.Close();
                    miCodigo.Close();
                    this.rutaArchivoGlobal = dialogoGuardar.FileName;
                }
            }
        }

        /// <summary>
        /// Guardo el código que este en pantalla automaticamente previo al proceso de análisis.
        /// </summary>
        /// <param name="ruta">Código fuente a guardar</param>
        private void GuardarArchivoTextoAutomatico(string ruta)
        {
            string[] arregloTexto = this.txtCodigoInicial.Lines;
            StreamWriter escribe;
            escribe = new StreamWriter(ruta);
            foreach (string linea in arregloTexto)
            {
                if (!string.IsNullOrEmpty(linea))
                {
                    escribe.WriteLine(linea);
                }
            }
            escribe.Close();
        }

        /// <summary>
        /// Método para generar el archivo ejecutable.
        /// </summary>
        private void GenerarEjecutable()
        {
            string nombreArchivo = string.Empty;
            try
            {
                if (rutaArchivoGlobal != string.Empty)
                {
                    if (File.Exists(rutaArchivoGlobal))
                    {
                        nombreArchivo = Path.GetFileNameWithoutExtension(rutaArchivoGlobal);
                    }
                    else
                    {
                        nombreArchivo = "temporal";
                    } 
                }
                clsEjecutable clsejec = new clsEjecutable();
                clsejec.TraducirCodigo(nombreArchivo, dt);
            }
            catch (Exception)
            {       
                throw;
            }
        }

        /// <summary>
        /// Inicio del proceso de análisis.
        /// </summary>
        private void Analizar()
        {
            try
            {
                this.txtInformacion.Text = string.Empty;
                this.EliminarRegistrosCompilacion();
                if (!string.IsNullOrEmpty(this.txtCodigoInicial.Text) && !string.IsNullOrWhiteSpace(this.txtCodigoInicial.Text))
                {
                    // Si rutaArchivoGlobal esta vacia entonces genero un dialogo para guardar el archivo.
                    if (string.IsNullOrEmpty(this.rutaArchivoGlobal))
                    {
                        this.GuardarArchivoTexto(this.txtCodigoInicial.Text);
                    }
                    else // Si rutaArchivoGlobal esta llena entonces se invoca el metodo para guardar cambios.
                    {
                        this.GuardarArchivoTextoAutomatico(this.rutaArchivoGlobal);
                    }
                    // Llamada a los 3 analizadores.
                    this.AnalisisLexico();
                    this.AnalisisSintactico();
                    this.AnalisisSemantico();
                    if (arrTexto.Count.Equals(0))
                    {
                        if (MessageBox.Show("¿La compilación fue exitosa desea generar el archivo ejecutable?", "Compilador [RSA]", MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(DialogResult.Yes))
                        {
                            this.GenerarEjecutable();
                            arrTexto.Clear();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese el código por Analizar antes de continuar!", "Compilador [RSA]", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Error" + ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Doy formato al texto del código con color.
        /// </summary>
        private void FormatoCodigoFinal()
        {
            try
            {
                // Desactivamos el control
                txtCodigoInicial.Enabled = false;

                // Guardamos la selecciona actual para regresar
                // todo a su sitio cuando terminemos
                int selStart = txtCodigoInicial.SelectionStart;
                int selLength = txtCodigoInicial.SelectionLength;

                // Nos aseguramos de que todo el texto
                // este negro antes de ponerle color
                txtCodigoInicial.SelectAll();
                txtCodigoInicial.SelectionColor = Color.Black;

                // Declaramos las variables necesarias
                Regex reg;
                MatchCollection partes;

                // Buscamos todas la palabras reservadas
                reg = new Regex("(inicio|fin|ent|txt|deci|si|finSi|entonces|sino|finSino|mientras|finMientras|desde|finDesde|hacer|pintar|finPintar|leer|convertir|aTexto|aEntero|aDecimal|espera)",RegexOptions.IgnoreCase);
                partes = reg.Matches(txtCodigoInicial.Text);
                for (int i = 0; i < partes.Count; i++)
                {
                    txtCodigoInicial.SelectionStart = partes[i].Index;
                    txtCodigoInicial.SelectionLength = partes[i].Length;
                    txtCodigoInicial.SelectionColor = Color.Blue;
                }

                // Buscamos todas las cadenas
                reg = new Regex("[\"][^\"]*[\"]");
                partes = reg.Matches(txtCodigoInicial.Text);
                for (int i = 0; i < partes.Count; i++)
                {
                    txtCodigoInicial.SelectionStart = partes[i].Index;
                    txtCodigoInicial.SelectionLength = partes[i].Length;
                    txtCodigoInicial.SelectionColor = Color.OrangeRed;
                }

                // Buscamos todas las cadenas
                reg = new Regex(@"[\#][^\#]*[\#]");
                partes = reg.Matches(txtCodigoInicial.Text);
                for (int i = 0; i < partes.Count; i++)
                {
                    txtCodigoInicial.SelectionStart = partes[i].Index;
                    txtCodigoInicial.SelectionLength = partes[i].Length;
                    txtCodigoInicial.SelectionColor = Color.Green;
                }

                // Regresamos todo a su sitio
                txtCodigoInicial.SelectionStart = selStart;
                txtCodigoInicial.SelectionLength = selLength;

                // Activamos el control
                txtCodigoInicial.Enabled = true;
                txtCodigoInicial.Focus();
            }
            catch (Exception)
            {

                throw;
            }
        }

        #endregion

        #region Eventos del sistema

        private void frmInicio_Load(object sender, EventArgs e)
        {
            try
            {
                this.CargarTabla();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.rutaArchivoGlobal = string.Empty;
            try
            {
                OpenFileDialog dialogo = new OpenFileDialog();
                dialogo.InitialDirectory = "c:\\";
                dialogo.Filter = "txt files (*.txt)|*.txt";
                dialogo.FilterIndex = 2;
                dialogo.RestoreDirectory = true;
                if (dialogo.ShowDialog() == DialogResult.OK)
                {
                    this.rutaArchivoGlobal = dialogo.FileName;
                    this.LeerArchivotxt(this.rutaArchivoGlobal);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al abrir el archivo...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnalizar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Analizar();
            }
            catch (Exception)
            {
                MessageBox.Show("Error en el proceso de análisis", "Compilador [RSA]", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.LimpiarTexto();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Dispose();
            base.Close();
        }

        private void txtCodigoInicial_MouseClick(object sender, MouseEventArgs e)
        {
            lblPosicion.Text = this.txtCodigoInicial.SelectionStart.ToString();
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(this.txtCodigoInicial.Text) && !string.IsNullOrWhiteSpace(this.txtCodigoInicial.Text))
                {
                    // Si rutaArchivoGlobal esta vacia entonces genero un dialogo para guardar el archivo.
                    if (string.IsNullOrEmpty(this.rutaArchivoGlobal))
                    {
                        this.GuardarArchivoTexto(this.txtCodigoInicial.Text);
                    }
                    else // Si rutaArchivoGlobal esta llena entonces se invoca el metodo para guardar cambios.
                    {
                        this.GuardarArchivoTextoAutomatico(this.rutaArchivoGlobal);
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese el código por Analizar antes de continuar!", "Compilador [RSA]", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No se puede guardar el archivo en este momento", "Compilador [RSA]", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void analizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Analizar();
            }
            catch (Exception)
            {
                MessageBox.Show("Error en el proceso de análisis", "Compilador [RSA]", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void restaurarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LimpiarTexto();
        }

        private void txtCodigoInicial_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.FormatoCodigoFinal();
            }
            catch
            {
            }
        }

        #endregion

        

        

    }
}
